#ifndef _SYS_TIME_H_
#error "must be included via <sys/time.h>"
#endif /* !_SYS_TIME_H_ */
